% readme instructions for GM estimation of the spatial error model
% replace the prt.m function in the 'util' folder of LeSage's Toolbox
% with the prt.m function in this folder.
